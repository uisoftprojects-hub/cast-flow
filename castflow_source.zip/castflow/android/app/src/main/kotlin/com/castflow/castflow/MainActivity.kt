package com.castflow.castflow

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_ce/hive.dart';

/// On-device structured storage (Hive CE). Values are plain maps so no
/// generated type adapters are needed.
class LocalStore {
  LocalStore({required this.history, required this.devices, required this.bookmarks, required this.webHistory});

  final Box<Map> history;
  final Box<Map> devices;
  final Box<Map> bookmarks;
  final Box<Map> webHistory;

  static const _names = ['history', 'devices', 'bookmarks', 'web_history'];

  /// Opens all boxes. Call `Hive.initFlutter()` (app) or `Hive.init(path)`
  /// (tests) first.
  static Future<LocalStore> open() async {
    final boxes = [for (final n in _names) await Hive.openBox<Map>(n)];
    return LocalStore(history: boxes[0], devices: boxes[1], bookmarks: boxes[2], webHistory: boxes[3]);
  }
}

/// Overridden in `main()` with the opened store.
final localStoreProvider = Provider<LocalStore>(
  (ref) => throw UnimplementedError('localStoreProvider must be overridden'),
);

/// Keeps a box to at most [max] entries, dropping the oldest by [timeKey].
Future<void> trimBox(Box<Map> box, int max, String timeKey) async {
  if (box.length <= max) return;
  final entries = box.toMap().entries.toList()
    ..sort((a, b) => (a.value[timeKey] as int).compareTo(b.value[timeKey] as int));
  await box.deleteAll(entries.take(box.length - max).map((e) => e.key));
}

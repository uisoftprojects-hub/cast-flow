import '../../../core/app_providers.dart';
import '../../player/domain/cast_media.dart';

/// Mock catalog for the YouTube and Google pickers. In production YouTube
/// metadata comes from youtube_explode_dart and Google media from the
/// Photos / Drive APIs after sign-in.
class MockAppContent {
  MockAppContent(this._mode);

  final PreviewMode Function() _mode;

  static const _yt = [
    ('Lo-fi beats to relax & study', 'Chill Lab', Duration(hours: 1, minutes: 2)),
    ('Top 10 hidden beaches in Portugal', 'Wander More', Duration(minutes: 14, seconds: 21)),
    ('Easy 15-minute pasta', 'Home Kitchen', Duration(minutes: 9, seconds: 48)),
    ('Northern lights 4K timelapse', 'Sky Stories', Duration(minutes: 6, seconds: 3)),
    ('Morning yoga flow', 'Calm Body', Duration(minutes: 22, seconds: 10)),
    ('Tiny house tour', 'Small Living', Duration(minutes: 17, seconds: 36)),
    ('Learn watercolor in 10 minutes', 'Art Daily', Duration(minutes: 10, seconds: 2)),
    ('Space documentary: Voyager', 'Cosmos Club', Duration(minutes: 48, seconds: 55)),
  ];

  Future<List<CastMedia>> youtube({String query = '', bool recent = false}) {
    return simulateFetch(_mode(), () {
      final list = [
        for (final (i, (title, channel, d)) in _yt.indexed)
          CastMedia(
            id: 'yt-$i',
            title: title,
            subtitle: channel,
            kind: CastKind.youtube,
            seed: 20 + i,
            duration: d,
          ),
      ];
      final filtered = query.isEmpty
          ? list
          : list.where((m) => m.title.toLowerCase().contains(query.toLowerCase())).toList();
      return recent ? filtered.reversed.take(4).toList() : filtered;
    });
  }

  Future<List<CastMedia>> google({required bool drive}) {
    return simulateFetch(
      _mode(),
      () => [
        for (var i = 0; i < (drive ? 9 : 18); i++)
          CastMedia(
            id: '${drive ? 'drive' : 'gp'}-$i',
            title: drive ? (i.isEven ? 'Presentation_${i + 1}.mp4' : 'Family_${i + 1}.jpg') : 'Google Photo ${i + 1}',
            subtitle: drive ? 'Google Drive' : 'Google Photos',
            kind: drive && i.isEven ? CastKind.video : CastKind.photo,
            seed: (drive ? 40 : 60) + i,
            duration: drive && i.isEven ? Duration(minutes: 2 + i) : Duration.zero,
          ),
      ],
    );
  }
}

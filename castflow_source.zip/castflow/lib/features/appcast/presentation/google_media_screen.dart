import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/effects.dart';
import '../../../core/widgets/selectors.dart';
import '../../../core/widgets/state_views.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../player/domain/cast_media.dart';
import '../../player/presentation/player_controller.dart';
import 'app_cast_providers.dart';

/// Google Photos / Drive picker. Sign-in is mocked as an account card.
class GoogleMediaScreen extends ConsumerStatefulWidget {
  const GoogleMediaScreen({super.key});

  @override
  ConsumerState<GoogleMediaScreen> createState() => _GoogleMediaScreenState();
}

class _GoogleMediaScreenState extends ConsumerState<GoogleMediaScreen> {
  bool _drive = false;
  final Set<String> _selected = {};

  @override
  Widget build(BuildContext context) {
    final media = ref.watch(googleMediaProvider(_drive));
    final p = context.palette;

    return Scaffold(
      appBar: const CastAppBar(title: 'Google'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpace.page, 0, AppSpace.page, AppSpace.md),
            child: SegmentedPills<bool>(
              values: const [false, true],
              selected: _drive,
              labelOf: (d) => d ? 'Drive' : 'Google Photos',
              onChanged: (d) => setState(() {
                _drive = d;
                _selected.clear();
              }),
            ),
          ),
          Expanded(
            child: AsyncView<List<CastMedia>>(
              value: media,
              loading: const ShimmerGrid(),
              onRetry: () => ref.invalidate(googleMediaProvider(_drive)),
              isEmpty: (m) => m.isEmpty,
              empty: EmptyState(
                icon: _drive ? Iconsax.folder_2_copy : Iconsax.gallery_copy,
                title: _drive ? 'No media in Drive' : 'No Google Photos',
                message: 'Photos and videos from your Google account will show up here.',
              ),
              data: (items) => Stack(
                children: [
                  GridView.builder(
                    padding: const EdgeInsets.fromLTRB(AppSpace.page, 0, AppSpace.page, 120),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      mainAxisSpacing: 10,
                      crossAxisSpacing: 10,
                    ),
                    itemCount: items.length,
                    itemBuilder: (_, i) {
                      final m = items[i];
                      final sel = _selected.contains(m.id);
                      return Semantics(
                        selected: sel,
                        child: TapScale(
                          semanticLabel: m.title,
                          onTap: () => setState(() => sel ? _selected.remove(m.id) : _selected.add(m.id)),
                          child: AnimatedScale(
                            duration: AppDurations.fast,
                            scale: sel ? 0.92 : 1,
                            child: MediaArt(
                              seed: m.seed,
                              icon: m.kind.icon,
                              iconSize: 22,
                              child: PositionedDirectional(
                                top: 8,
                                end: 8,
                                child: Container(
                                  width: 24,
                                  height: 24,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: sel ? p.primary : Colors.white.withValues(alpha: 0.5),
                                    border: Border.all(color: Colors.white, width: 2),
                                  ),
                                  child: sel ? const Icon(Icons.check_rounded, size: 14, color: Colors.white) : null,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ).animate(delay: ((i > 12 ? 12 : i) * 25).ms).fadeIn(duration: 300.ms);
                    },
                  ),
                  PositionedDirectional(
                    start: AppSpace.page,
                    end: AppSpace.page,
                    bottom: AppSpace.xxl,
                    child: SafeArea(
                      top: false,
                      child: AnimatedSlide(
                        duration: AppDurations.medium,
                        offset: _selected.isEmpty ? const Offset(0, 2) : Offset.zero,
                        child: GlassPanel(
                          radius: AppRadius.pill,
                          padding: const EdgeInsets.all(AppSpace.sm),
                          child: Row(
                            children: [
                              const SizedBox(width: AppSpace.md),
                              Expanded(child: Text('${_selected.length} selected', style: context.text.labelLarge)),
                              GradientButton(
                                label: 'Cast',
                                icon: Iconsax.screenmirroring_copy,
                                compact: true,
                                onPressed: () => castAndOpenRemote(
                                  context,
                                  ref,
                                  items.where((m) => _selected.contains(m.id)).toList(),
                                  slideshowInterval: const Duration(seconds: 5),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

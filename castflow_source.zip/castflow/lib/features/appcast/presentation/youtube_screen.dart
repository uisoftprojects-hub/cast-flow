import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/format.dart';
import '../../../core/widgets/effects.dart';
import '../../../core/widgets/selectors.dart';
import '../../../core/widgets/state_views.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../player/domain/cast_media.dart';
import '../../player/presentation/player_controller.dart';
import 'app_cast_providers.dart';

class YoutubeScreen extends ConsumerStatefulWidget {
  const YoutubeScreen({super.key});

  @override
  ConsumerState<YoutubeScreen> createState() => _YoutubeScreenState();
}

class _YoutubeScreenState extends ConsumerState<YoutubeScreen> {
  String _query = '';
  bool _recent = false;
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _onSearch(String v) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 350), () => setState(() => _query = v.trim()));
  }

  @override
  Widget build(BuildContext context) {
    final key = (query: _query, recent: _recent);
    final videos = ref.watch(youtubeProvider(key));

    return Scaffold(
      appBar: const CastAppBar(title: 'YouTube'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppSpace.page),
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.pill),
                boxShadow: AppShadows.soft(context.palette),
              ),
              child: TextField(
                onChanged: _onSearch,
                textInputAction: TextInputAction.search,
                decoration: InputDecoration(
                  hintText: 'Search YouTube',
                  prefixIcon: Icon(Iconsax.search_normal_1_copy, color: context.palette.textSecondary, size: 20),
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.lg, AppSpace.page, AppSpace.sm),
            child: SegmentedPills<bool>(
              values: const [false, true],
              selected: _recent,
              labelOf: (r) => r ? 'Recent' : 'Trending',
              onChanged: (r) => setState(() => _recent = r),
            ),
          ),
          Expanded(
            child: AsyncView<List<CastMedia>>(
              value: videos,
              loading: const ShimmerGrid(crossAxisCount: 2, count: 6),
              onRetry: () => ref.invalidate(youtubeProvider(key)),
              isEmpty: (v) => v.isEmpty,
              empty: EmptyState(
                icon: Iconsax.search_normal_1_copy,
                title: _query.isEmpty ? 'Nothing here yet' : 'No results',
                message: _query.isEmpty ? 'Videos you watch will appear here.' : 'Try a different search term.',
              ),
              data: (items) => LayoutBuilder(
                builder: (context, c) => GridView.builder(
                  padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.sm, AppSpace.page, AppSpace.xxxl),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: c.maxWidth > 600 ? 3 : 2,
                    mainAxisSpacing: AppSpace.lg,
                    crossAxisSpacing: AppSpace.md,
                    // Leaves room for two lines of title + channel at any text scale.
                    mainAxisExtent: (c.maxWidth / (c.maxWidth > 600 ? 3 : 2)) * 0.6 +
                        MediaQuery.textScalerOf(context).scale(66),
                  ),
                  itemCount: items.length,
                  itemBuilder: (context, i) => _VideoCard(
                    media: items[i],
                    onTap: () => castAndOpenRemote(context, ref, [items[i]]),
                  ).animate(delay: (40 * i).ms).fadeIn(duration: 300.ms),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _VideoCard extends StatelessWidget {
  const _VideoCard({required this.media, required this.onTap});
  final CastMedia media;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return TapScale(
      onTap: onTap,
      semanticLabel: '${media.title} by ${media.subtitle}. Cast',
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AspectRatio(
            aspectRatio: 16 / 10,
            child: MediaArt(
              seed: media.seed,
              icon: Iconsax.play_circle_copy,
              child: PositionedDirectional(
                end: 6,
                bottom: 6,
                child: SoftBadge(formatDuration(media.duration), color: Colors.black.withValues(alpha: 0.4), textColor: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(media.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: context.text.labelMedium),
          Text(media.subtitle ?? '', maxLines: 1, overflow: TextOverflow.ellipsis, style: context.text.bodySmall),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/widgets/soft_card.dart';
import '../../devices/presentation/widgets/connection_chip.dart';

class _AppCard {
  const _AppCard(this.name, this.tagline, this.icon, this.color, this.route, this.features);
  final String name;
  final String tagline;
  final IconData icon;
  final Color color;
  final String route;
  final List<String> features;
}

const _apps = [
  _AppCard('YouTube', 'Search, trending & your recent videos', Iconsax.youtube_copy, Color(0xFFE62117), '/apps/youtube',
      ['Search', 'Trending', 'Recent']),
  _AppCard('Google', 'Google Photos & Drive media', Iconsax.google_copy, Color(0xFF4285F4), '/apps/google',
      ['Photos', 'Drive']),
  _AppCard('Facebook', 'Watch videos with auto-detection', Iconsax.facebook_copy, Color(0xFF1877F2), '/apps/facebook',
      ['Watch', 'Reels', 'Live']),
];

class AppCastHubScreen extends StatelessWidget {
  const AppCastHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CastAppBar(title: 'Cast from apps'),
      body: ListView.separated(
        padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.sm, AppSpace.page, AppSpace.xxxl),
        itemCount: _apps.length,
        separatorBuilder: (_, _) => const SizedBox(height: AppSpace.lg),
        itemBuilder: (context, i) {
          final a = _apps[i];
          return SoftCard(
            onTap: () => context.push(a.route),
            semanticLabel: '${a.name}. ${a.tagline}',
            padding: EdgeInsets.zero,
            child: Container(
              padding: const EdgeInsets.all(AppSpace.xl),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(AppRadius.lg),
                gradient: LinearGradient(
                  begin: AlignmentDirectional.topStart,
                  end: AlignmentDirectional.bottomEnd,
                  colors: [a.color.withValues(alpha: context.isDark ? 0.22 : 0.16), a.color.withValues(alpha: 0.04)],
                ),
              ),
              child: Row(
                children: [
                  IconBubble(icon: a.icon, color: a.color, size: 64, filled: true),
                  const SizedBox(width: AppSpace.lg),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(a.name, style: context.text.headlineSmall),
                        const SizedBox(height: 2),
                        Text(a.tagline, style: context.text.bodySmall),
                        const SizedBox(height: AppSpace.sm),
                        Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: [
                            for (final f in a.features)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                                decoration: BoxDecoration(
                                  color: context.palette.surface,
                                  borderRadius: BorderRadius.circular(AppRadius.pill),
                                ),
                                child: Text(f, style: context.text.labelSmall?.copyWith(color: a.color)),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const ForwardChevron(),
                ],
              ),
            ),
          ).animate(delay: (80 * i).ms).fadeIn(duration: 400.ms).slideY(begin: 0.1, end: 0);
        },
      ),
    );
  }
}

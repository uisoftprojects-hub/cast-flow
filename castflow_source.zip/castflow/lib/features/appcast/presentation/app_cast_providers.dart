import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/app_providers.dart';
import '../../player/domain/cast_media.dart';
import '../data/mock_app_content.dart';

final appContentProvider = Provider<MockAppContent>((ref) => MockAppContent(() => ref.read(previewModeProvider)));

typedef YoutubeQuery = ({String query, bool recent});

final youtubeProvider = FutureProvider.family<List<CastMedia>, YoutubeQuery>((ref, q) {
  ref.watch(previewModeProvider);
  return ref.watch(appContentProvider).youtube(query: q.query, recent: q.recent);
});

final googleMediaProvider = FutureProvider.family<List<CastMedia>, bool>((ref, drive) {
  ref.watch(previewModeProvider);
  return ref.watch(appContentProvider).google(drive: drive);
});

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/format.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/effects.dart';
import '../../../core/widgets/illustrations.dart';
import '../../../core/widgets/soft_card.dart';
import '../../../core/widgets/state_views.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../devices/presentation/device_providers.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../devices/presentation/widgets/connection_guide_sheet.dart';
import '../../history/domain/history_entry.dart';
import '../../history/presentation/history_controller.dart';
import '../../player/presentation/player_controller.dart';

class _Tile {
  const _Tile(this.title, this.subtitle, this.icon, this.color, this.route);
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final String route;
}

const _media = [
  _Tile('Photos', 'Albums', Iconsax.gallery_copy, AppColors.primary, '/photos'),
  _Tile('Videos', 'Gallery', Iconsax.video_play_copy, Color(0xFFFF7A59), '/videos'),
  _Tile('Music', 'Songs', Iconsax.music_copy, Color(0xFF12B886), '/music'),
];

String _web(String url) => '/web?url=${Uri.encodeComponent(url)}';

final _apps = [
  const _Tile('Facebook', '', Iconsax.facebook_copy, Color(0xFF1877F2), '/apps/facebook'),
  const _Tile('YouTube', '', Iconsax.youtube_copy, Color(0xFFE62117), '/apps/youtube'),
  const _Tile('Google', '', Iconsax.google_copy, Color(0xFF4285F4), '/apps/google'),
  _Tile('Instagram', '', Iconsax.instagram_copy, const Color(0xFFE1306C), _web('https://www.instagram.com')),
  _Tile('Vimeo', '', Iconsax.video_circle_copy, const Color(0xFF1AB7EA), _web('https://vimeo.com')),
  _Tile('Twitch', '', Iconsax.twitch_copy, const Color(0xFF9146FF), _web('https://m.twitch.tv')),
  _Tile('Dailymotion', '', Iconsax.video_square_copy, const Color(0xFF0066DC), _web('https://www.dailymotion.com')),
  const _Tile('IPTV / Link', '', Iconsax.link_2_copy, Color(0xFFF59E0B), '/link'),
];

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: RefreshIndicator(
          onRefresh: () => ref.read(historyProvider.notifier).refresh(),
          child: ListView(
            padding: EdgeInsets.fromLTRB(AppSpace.page, AppSpace.lg, AppSpace.page, navBottomPadding(context)),
            children: [
              const _Header(),
              const SizedBox(height: AppSpace.xl),
              const _MirrorCard(),
              const SizedBox(height: AppSpace.md),
              const _RemoteAndApps(),
              const SizedBox(height: AppSpace.xxl),
              const SectionHeader('Media'),
              const _MediaRow(),
              const SizedBox(height: AppSpace.xxl),
              const SectionHeader('Web browser'),
              const _BrowserBar(),
              const SizedBox(height: AppSpace.xxl),
              SectionHeader('Cast from apps', action: 'See all', onAction: () => context.push('/apps')),
              const _AppGrid(),
              const SizedBox(height: AppSpace.xxl),
              SectionHeader('Recently cast', action: 'See all', onAction: () => context.go('/history')),
              const _RecentList(),
              const SizedBox(height: AppSpace.xl),
              const _HelpBanner(),
            ],
          ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(greeting(), style: context.text.bodyMedium),
                  Text('CastFlow', style: context.text.headlineLarge),
                ],
              ),
            ),
            TapScale(
              onTap: () => context.push('/premium'),
              semanticLabel: 'Go Premium',
              child: Container(
                constraints: const BoxConstraints(minHeight: kMinTap),
                padding: const EdgeInsets.symmetric(horizontal: 14),
                decoration: BoxDecoration(
                  color: const Color(0xFFFFF1E8),
                  borderRadius: BorderRadius.circular(AppRadius.pill),
                  border: Border.all(color: const Color(0xFFFFD3BD)),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Iconsax.crown_1_copy, size: 18, color: Color(0xFFE8590C)),
                    const SizedBox(width: 6),
                    Text('PRO', style: context.text.labelMedium?.copyWith(color: const Color(0xFFE8590C))),
                  ],
                ),
              ),
            ),
            const SizedBox(width: AppSpace.sm),
            SoftIconButton(
              icon: Iconsax.setting_2_copy,
              tooltip: 'Settings',
              onPressed: () => context.go('/settings'),
            ),
          ],
        ),
        const SizedBox(height: AppSpace.md),
        const ConnectionChip(),
      ],
    ).animate().fadeIn(duration: 300.ms);
  }
}

/// Main container: screen mirroring.
class _MirrorCard extends ConsumerWidget {
  const _MirrorCard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final device = ref.watch(connectionProvider.select((c) => c.isConnected ? c.device?.name : null));
    return TapScale(
      onTap: () => context.push('/mirror'),
      semanticLabel: 'Screen Mirroring. Start mirroring',
      child: Container(
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFF1E1B4B), Color(0xFF4338CA)],
          ),
          borderRadius: BorderRadius.circular(AppRadius.xl),
          boxShadow: AppShadows.glow(const Color(0xFF312E81)),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            PositionedDirectional(
              end: -40,
              bottom: -60,
              child: Container(
                width: 180,
                height: 180,
                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white.withValues(alpha: 0.06)),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(AppSpace.xl),
              child: Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: device != null ? const Color(0xFF4ADE80) : Colors.white54,
                              ),
                            ),
                            const SizedBox(width: 6),
                            Flexible(
                              child: Text(
                                device != null ? 'Ready · $device' : 'No TV connected',
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: context.text.labelSmall?.copyWith(color: Colors.white70),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: AppSpace.sm),
                        Text('Screen Mirroring', style: context.text.headlineMedium?.copyWith(color: Colors.white)),
                        const SizedBox(height: 2),
                        Text(
                          'Show your phone on the TV in real time.',
                          style: context.text.bodySmall?.copyWith(color: Colors.white70),
                        ),
                        const SizedBox(height: AppSpace.lg),
                        GradientButton(
                          label: 'Start Mirroring',
                          icon: Iconsax.screenmirroring_copy,
                          gradient: const LinearGradient(colors: [Colors.white, Colors.white]),
                          foreground: const Color(0xFF312E81),
                          compact: true,
                          onPressed: () => context.push('/mirror'),
                        ),
                      ],
                    ),
                  ),
                  const ExcludeSemantics(
                    child: CastIllustration(kind: IllustrationKind.mirror, size: 96, onGradient: true),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    ).animate().fadeIn(duration: 350.ms).slideY(begin: 0.04, end: 0);
  }
}

/// Remote + Apps, side by side under the main container.
class _RemoteAndApps extends ConsumerWidget {
  const _RemoteAndApps();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final nowPlaying = ref.watch(playerProvider.select((s) => s.media?.title));
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: _ActionCard(
              icon: Iconsax.mobile_copy,
              color: AppColors.primary,
              title: 'Remote',
              subtitle: nowPlaying != null ? 'Now: $nowPlaying' : 'Control your TV',
              // Needs a TV: without one, discovery opens with an explanation.
              onTap: () async {
                if (await ensureConnected(context, ref, reason: 'remote') && context.mounted) {
                  context.push('/remote');
                }
              },
            ),
          ),
          const SizedBox(width: AppSpace.md),
          Expanded(
            child: _ActionCard(
              icon: Iconsax.element_3_copy,
              color: const Color(0xFFFF7A59),
              title: 'Apps',
              subtitle: 'YouTube & more',
              onTap: () => context.push('/apps'),
            ),
          ),
        ],
      ),
    ).animate().fadeIn(delay: 80.ms, duration: 300.ms);
  }
}

class _ActionCard extends StatelessWidget {
  const _ActionCard({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      padding: const EdgeInsets.all(AppSpace.md),
      onTap: onTap,
      semanticLabel: '$title. $subtitle',
      child: Row(
        children: [
          IconBubble(icon: icon, color: color, size: 44, filled: true),
          const SizedBox(width: AppSpace.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: context.text.titleSmall),
                Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.text.bodySmall),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MediaRow extends StatelessWidget {
  const _MediaRow();

  @override
  Widget build(BuildContext context) {
    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final (i, m) in _media.indexed) ...[
            if (i > 0) const SizedBox(width: AppSpace.md),
            Expanded(
              child: SoftCard(
                padding: const EdgeInsets.all(AppSpace.md),
                onTap: () => context.push(m.route),
                semanticLabel: 'Cast ${m.title}',
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    IconBubble(icon: m.icon, color: m.color, size: 44, filled: true),
                    const SizedBox(height: AppSpace.md),
                    Text(m.title, style: context.text.titleSmall),
                    Text(m.subtitle, style: context.text.bodySmall),
                  ],
                ),
              ).animate(delay: (120 + 40 * i).ms).fadeIn(duration: 300.ms).slideY(begin: 0.08, end: 0),
            ),
          ],
        ],
      ),
    );
  }
}

/// Search / URL bar that opens Web Cast.
class _BrowserBar extends StatefulWidget {
  const _BrowserBar();

  @override
  State<_BrowserBar> createState() => _BrowserBarState();
}

class _BrowserBarState extends State<_BrowserBar> {
  final _ctrl = TextEditingController();

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _go() {
    final text = _ctrl.text.trim();
    context.push(text.isEmpty ? '/web' : _web(text));
    _ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      padding: const EdgeInsetsDirectional.only(start: 16, end: 6),
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(AppRadius.md),
        border: Border.all(color: p.divider),
        boxShadow: AppShadows.soft(p),
      ),
      child: Row(
        children: [
          Icon(Iconsax.global_copy, size: 20, color: p.textSecondary),
          Expanded(
            child: TextField(
              controller: _ctrl,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.go,
              autocorrect: false,
              onSubmitted: (_) => _go(),
              style: context.text.bodyLarge,
              decoration: const InputDecoration(
                hintText: 'Search or type a website',
                filled: false,
                contentPadding: EdgeInsets.symmetric(horizontal: 10, vertical: 16),
              ),
            ),
          ),
          SoftIconButton(
            icon: Iconsax.search_normal_1_copy,
            tooltip: 'Open in Web Cast',
            filled: true,
            size: 44,
            onPressed: _go,
          ),
        ],
      ),
    );
  }
}

class _AppGrid extends StatelessWidget {
  const _AppGrid();

  @override
  Widget build(BuildContext context) {
    const perRow = 4;
    return Column(
      children: [
        for (var r = 0; r < _apps.length; r += perRow) ...[
          if (r > 0) const SizedBox(height: AppSpace.lg),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              for (final (i, a) in _apps.sublist(r, (r + perRow).clamp(0, _apps.length)).indexed)
                Expanded(
                  child: TapScale(
                    onTap: () => context.push(a.route),
                    semanticLabel: 'Cast from ${a.title}',
                    child: Column(
                      children: [
                        Container(
                          width: 56,
                          height: 56,
                          decoration: BoxDecoration(
                            color: a.color,
                            borderRadius: BorderRadius.circular(AppRadius.md),
                            boxShadow: AppShadows.glow(a.color),
                          ),
                          child: Icon(a.icon, color: Colors.white, size: 26),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          a.title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          textAlign: TextAlign.center,
                          style: context.text.labelSmall?.copyWith(color: context.palette.textPrimary),
                        ),
                      ],
                    ),
                  ).animate(delay: (40 * (r + i)).ms).fadeIn(duration: 300.ms).scale(begin: const Offset(0.9, 0.9)),
                ),
            ],
          ),
        ],
      ],
    );
  }
}

class _RecentList extends ConsumerWidget {
  const _RecentList();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final history = ref.watch(historyProvider);
    const height = 164.0;
    return history.when(
      loading: () => SizedBox(
        height: height,
        child: SoftShimmer(
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: 4,
            separatorBuilder: (_, _) => const SizedBox(width: AppSpace.md),
            itemBuilder: (_, _) => const ShimmerBox(width: 136, height: height, radius: AppRadius.md),
          ),
        ),
      ),
      error: (_, _) => SoftCard(
        child: Row(
          children: [
            IconBubble(icon: Iconsax.danger_copy, color: context.palette.error),
            const SizedBox(width: AppSpace.lg),
            Expanded(child: Text('Couldn’t load your recent casts.', style: context.text.bodyMedium)),
            TintedButton(label: 'Retry', compact: true, onPressed: () => ref.read(historyProvider.notifier).refresh()),
          ],
        ),
      ),
      data: (items) {
        if (items.isEmpty) {
          return SoftCard(
            child: Row(
              children: [
                const IconBubble(icon: Iconsax.clock_copy),
                const SizedBox(width: AppSpace.lg),
                Expanded(
                  child: Text('Nothing cast yet. Your recent casts will show up here.',
                      style: context.text.bodyMedium),
                ),
              ],
            ),
          );
        }
        final recent = items.take(8).toList();
        return SizedBox(
          height: height,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            clipBehavior: Clip.none,
            itemCount: recent.length,
            separatorBuilder: (_, _) => const SizedBox(width: AppSpace.md),
            itemBuilder: (_, i) => _RecentCard(recent[i]),
          ),
        );
      },
    );
  }
}

class _RecentCard extends StatelessWidget {
  const _RecentCard(this.e);
  final HistoryEntry e;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 136,
      child: SoftCard(
        padding: const EdgeInsets.all(AppSpace.sm),
        onTap: () => context.go('/history'),
        semanticLabel: '${e.title}, ${e.kind.label} on ${e.deviceName}',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: MediaArt(seed: e.seed, icon: e.kind.icon, radius: AppRadius.sm)),
            const SizedBox(height: AppSpace.sm),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(e.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.text.labelMedium),
                  Text(e.deviceName, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.text.bodySmall),
                ],
              ),
            ),
            const SizedBox(height: 4),
          ],
        ),
      ),
    );
  }
}

class _HelpBanner extends StatelessWidget {
  const _HelpBanner();

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      onTap: () => showConnectionGuide(context),
      semanticLabel: 'How to connect. Open step-by-step guide',
      child: Row(
        children: [
          const IconBubble(icon: Iconsax.message_question_copy, color: Color(0xFF12B886), size: 44),
          const SizedBox(width: AppSpace.lg),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('How to connect', style: context.text.titleSmall),
                Text('Step-by-step guide for any TV', style: context.text.bodySmall),
              ],
            ),
          ),
          const ForwardChevron(),
        ],
      ),
    );
  }
}

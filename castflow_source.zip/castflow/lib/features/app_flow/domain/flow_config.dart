/// Steps of the startup journey. Each maps to exactly one route.
enum FlowStep {
  entry('/entry'),
  paywallFirstRunA('/paywall?slot=a'),
  language('/language'),
  paywallFirstRunB('/paywall?slot=b'),
  onboarding('/onboarding'),
  permissions('/permissions'),
  paywallReturning('/paywall?slot=returning'),
  home('/home');

  const FlowStep(this.route);
  final String route;

  bool get isPaywall => this == paywallFirstRunA || this == paywallFirstRunB || this == paywallReturning;
}

/// Local build-time switches for the startup journey (no remote config).
/// Turning a paywall slot off removes it without changing any routing code.
class FlowConfig {
  const FlowConfig({
    this.paywallFirstRunA = true,
    this.paywallFirstRunB = true,
    this.paywallReturning = true,
    this.showPermissions = true,
  });

  final bool paywallFirstRunA;
  final bool paywallFirstRunB;
  final bool paywallReturning;
  final bool showPermissions;
}

/// Builds the ordered steps for this launch.
///
/// First run:  Entry → Paywall A → Entry → Language → Paywall B → Onboarding
///             → Permissions → Home
/// Returning:  Entry → Paywall → Entry → Home
///
/// Completed milestones (language chosen, onboarding done) are skipped so a
/// launch that was interrupted resumes at a predictable step.
List<FlowStep> buildFlow({
  required FlowConfig config,
  required bool firstLaunchCompleted,
  required bool onboardingDone,
  required bool languageChosen,
  required bool isPremium,
}) {
  final steps = <FlowStep>[];
  if (!firstLaunchCompleted) {
    steps.add(FlowStep.entry);
    if (config.paywallFirstRunA && !isPremium) steps.addAll([FlowStep.paywallFirstRunA, FlowStep.entry]);
    if (!languageChosen) steps.add(FlowStep.language);
    if (!onboardingDone) {
      if (config.paywallFirstRunB && !isPremium) steps.add(FlowStep.paywallFirstRunB);
      steps.add(FlowStep.onboarding);
    }
    if (config.showPermissions) steps.add(FlowStep.permissions);
  } else {
    steps.add(FlowStep.entry);
    if (config.paywallReturning && !isPremium) steps.addAll([FlowStep.paywallReturning, FlowStep.entry]);
  }
  steps.add(FlowStep.home);

  // Never show the same gate twice in a row (e.g. when a paywall slot is off).
  final deduped = <FlowStep>[];
  for (final s in steps) {
    if (deduped.isEmpty || deduped.last != s) deduped.add(s);
  }
  return deduped;
}

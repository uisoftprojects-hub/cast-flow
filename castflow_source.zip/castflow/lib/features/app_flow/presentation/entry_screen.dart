import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/config/app_links.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/launch.dart';
import '../../../core/widgets/app_logo.dart';
import '../../../core/widgets/buttons.dart';
import '../../settings/presentation/settings_controller.dart';
import '../domain/flow_config.dart';
import 'app_flow_controller.dart';

/// Lightweight continue gate between Splash and the next startup step.
/// One route, reused for every gate position in the flow.
class EntryScreen extends ConsumerWidget {
  const EntryScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final flow = ref.watch(appFlowProvider);
    final returning = ref.watch(settingsProvider.select((s) => s.firstLaunchCompleted));
    final isFirstGate = flow.index <= 0;
    final p = context.palette;

    final (title, body) = switch ((isFirstGate, returning)) {
      (true, false) => ('Welcome to CastFlow', 'Mirror your screen and cast photos, videos and music to any TV on your Wi-Fi.'),
      (true, true) => ('Welcome back', 'Your TV is just a tap away.'),
      (false, false) => ('Let’s get you set up', 'Pick your language and take a quick tour.'),
      (false, true) => ('You’re all set', 'Continue to your casting dashboard.'),
    };

    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(AppSpace.xxl, AppSpace.lg, AppSpace.xxl, AppSpace.xxl),
          child: Column(
            children: [
              Expanded(
                child: Center(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                          decoration: BoxDecoration(
                            gradient: AppColors.mainGradient,
                            borderRadius: BorderRadius.circular(AppRadius.xl),
                            boxShadow: AppShadows.glow(AppColors.primary),
                          ),
                          child: const AppLogo(size: 104, background: Colors.transparent),
                        ).animate().fadeIn(duration: 400.ms).scale(begin: const Offset(0.9, 0.9)),
                        const SizedBox(height: AppSpace.xxl),
                        Text(title, textAlign: TextAlign.center, style: context.text.headlineLarge),
                        const SizedBox(height: AppSpace.sm),
                        Text(body, textAlign: TextAlign.center, style: context.text.bodyMedium),
                      ],
                    ).animate(key: ValueKey(flow.index)).fadeIn(duration: 350.ms).slideY(begin: 0.04, end: 0),
                  ),
                ),
              ),
              GradientButton(
                label: 'Continue',
                icon: Iconsax.arrow_right_3_copy,
                expand: true,
                onPressed: () {
                  final next = ref.read(appFlowProvider.notifier).advance(FlowStep.entry);
                  if (next != null) context.go(next);
                },
              ),
              const SizedBox(height: AppSpace.md),
              Text.rich(
                TextSpan(
                  style: context.text.bodySmall,
                  children: [
                    const TextSpan(text: 'By continuing you agree to our '),
                    TextSpan(
                      text: 'Terms',
                      style: TextStyle(color: p.primary, fontWeight: FontWeight.w600),
                      recognizer: TapGestureRecognizer()..onTap = () => openExternal(context, AppLinks.terms),
                    ),
                    const TextSpan(text: ' and '),
                    TextSpan(
                      text: 'Privacy Policy',
                      style: TextStyle(color: p.primary, fontWeight: FontWeight.w600),
                      recognizer: TapGestureRecognizer()..onTap = () => openExternal(context, AppLinks.privacyPolicy),
                    ),
                    const TextSpan(text: '.'),
                  ],
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

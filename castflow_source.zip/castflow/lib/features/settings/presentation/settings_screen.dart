import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';
import 'package:in_app_review/in_app_review.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/app_providers.dart';
import '../../../core/config/app_links.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/launch.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/selectors.dart';
import '../../../core/widgets/soft_card.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../devices/presentation/device_providers.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../history/presentation/history_controller.dart';
import '../../webcast/presentation/browser_controller.dart';
import '../domain/app_settings.dart';
import 'settings_controller.dart';

final packageInfoProvider = FutureProvider<PackageInfo>((ref) => PackageInfo.fromPlatform());

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  Future<bool> _confirm(BuildContext context, String title, String body, String action) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(action, style: TextStyle(color: context.palette.error)),
          ),
        ],
      ),
    );
    return ok == true;
  }

  /// Opens the mail app with diagnostics pre-filled. The user reviews and
  /// sends it; nothing is transmitted silently.
  Future<void> _feedback(BuildContext context, WidgetRef ref) async {
    final messenger = ScaffoldMessenger.of(context);
    final info = await PackageInfo.fromPlatform();
    var os = defaultTargetPlatform.name;
    var model = 'unknown';
    try {
      final d = DeviceInfoPlugin();
      if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
        final a = await d.androidInfo;
        os = 'Android ${a.version.release} (SDK ${a.version.sdkInt})';
        model = '${a.manufacturer} ${a.model}';
      } else if (!kIsWeb && defaultTargetPlatform == TargetPlatform.iOS) {
        final i = await d.iosInfo;
        os = '${i.systemName} ${i.systemVersion}';
        model = i.utsname.machine;
      }
    } catch (_) {}
    final receiver = ref.read(connectionProvider).device?.type.label ??
        ref.read(savedDevicesProvider).all().firstOrNull?.type.label ??
        'none';
    final body = '\n\n---\nApp: ${info.version} (${info.buildNumber})\nOS: $os\nPhone: $model\nReceiver: $receiver';
    final uri = Uri(
      scheme: 'mailto',
      path: AppLinks.supportEmail,
      query: 'subject=${Uri.encodeComponent('CastFlow feedback')}&body=${Uri.encodeComponent(body)}',
    );
    final ok = await launchUrl(uri).catchError((_) => false);
    if (!ok) messenger.showSnackBar(const SnackBar(content: Text('No email app found.')));
  }

  /// Official in-app review flow, at most once every 90 days; otherwise the
  /// store listing opens instead of repeating the prompt.
  Future<void> _rate(BuildContext context, WidgetRef ref) async {
    final last = ref.read(settingsProvider).lastReviewPromptAt;
    final review = InAppReview.instance;
    final recent = last != null && DateTime.now().difference(last) < const Duration(days: 90);
    if (!recent && !kIsWeb && await review.isAvailable()) {
      ref.read(settingsProvider.notifier).markReviewPrompted();
      await review.requestReview();
    } else if (context.mounted) {
      await openExternal(context, storeListingUrl);
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final s = ref.watch(settingsProvider);
    final ctrl = ref.read(settingsProvider.notifier);
    final version = ref.watch(packageInfoProvider).value;

    return Scaffold(
      appBar: const CastAppBar(title: 'Settings'),
      body: ListView(
        padding: EdgeInsets.fromLTRB(AppSpace.page, AppSpace.sm, AppSpace.page, navBottomPadding(context)),
        children: [
          // 1. Pro card
          _PremiumCard(active: s.isPremium),
          const SizedBox(height: AppSpace.xxl),
          // 2. Language
          const _GroupTitle('General'),
          _Group(
            children: [
              _Tile(
                icon: Iconsax.language_square_copy,
                title: 'Language',
                trailing: _Value(supportedLanguages[s.languageCode]?.$1 ?? 'English'),
                onTap: () => context.push('/settings/language'),
              ),
            ],
          ),
          const SizedBox(height: AppSpace.xxl),
          // 3. Theme
          const _GroupTitle('Appearance'),
          SegmentedPills<ThemeMode>(
            values: const [ThemeMode.system, ThemeMode.light, ThemeMode.dark],
            selected: s.themeMode,
            labelOf: (m) => switch (m) {
              ThemeMode.light => 'Light',
              ThemeMode.dark => 'Dark',
              ThemeMode.system => 'System',
            },
            onChanged: ctrl.setThemeMode,
          ),
          const SizedBox(height: AppSpace.xxl),
          // 4. Casting preferences
          const _GroupTitle('Casting'),
          _Group(
            children: [
              _Tile(
                icon: Iconsax.video_horizontal_copy,
                title: 'Default quality',
                trailing: _Value(s.defaultQuality.label),
                onTap: () => _pick<MirrorQuality>(
                  context,
                  title: 'Default quality',
                  values: MirrorQuality.values,
                  selected: s.defaultQuality,
                  labelOf: (q) => q.label,
                  onSelected: ctrl.setDefaultQuality,
                ),
              ),
              _Tile(
                icon: Iconsax.routing_2_copy,
                title: 'Preferred connection',
                trailing: _Value(s.connectionPreference.label),
                onTap: () => _pick<ConnectionPreference>(
                  context,
                  title: 'Preferred connection',
                  values: ConnectionPreference.values,
                  selected: s.connectionPreference,
                  labelOf: (c) => c.label,
                  onSelected: ctrl.setConnectionPreference,
                ),
              ),
              _Tile(
                icon: Iconsax.volume_high_copy,
                title: 'Audio output',
                subtitle: 'Where supported by the TV',
                trailing: _Value(s.audioOutput.label),
                onTap: () => _pick<AudioOutput>(
                  context,
                  title: 'Audio output',
                  values: AudioOutput.values,
                  selected: s.audioOutput,
                  labelOf: (a) => a.label,
                  onSelected: ctrl.setAudioOutput,
                ),
              ),
              _Tile(
                icon: Iconsax.refresh_copy,
                title: 'Auto-connect to last TV',
                subtitle: 'Reconnect when you open CastFlow',
                trailing: Switch(value: s.autoConnect, onChanged: ctrl.setAutoConnect),
                onTap: () => ctrl.setAutoConnect(!s.autoConnect),
              ),
            ],
          ),
          const SizedBox(height: AppSpace.xxl),
          // 5. Remote preferences
          const _GroupTitle('Remote'),
          _Group(
            children: [
              _Tile(
                icon: Iconsax.mobile_copy,
                title: 'Haptic feedback',
                trailing: Switch(value: s.hapticsEnabled, onChanged: ctrl.setHaptics),
                onTap: () => ctrl.setHaptics(!s.hapticsEnabled),
              ),
              _Tile(
                icon: Iconsax.sound_copy,
                title: 'Button sound',
                trailing: Switch(value: s.buttonSound, onChanged: ctrl.setButtonSound),
                onTap: () => ctrl.setButtonSound(!s.buttonSound),
              ),
              _Tile(
                icon: Iconsax.element_3_copy,
                title: 'Remote layout',
                trailing: _Value(s.remoteLayout.label),
                onTap: () => _pick<RemoteLayout>(
                  context,
                  title: 'Remote layout',
                  values: RemoteLayout.values,
                  selected: s.remoteLayout,
                  labelOf: (l) => l.label,
                  onSelected: ctrl.setRemoteLayout,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppSpace.xxl),
          // 6. History & storage
          const _GroupTitle('History & storage'),
          _Group(
            children: [
              _Tile(
                icon: Iconsax.clock_copy,
                title: 'Clear casting history',
                onTap: () async {
                  if (await _confirm(context, 'Clear casting history?', 'Your list of recent casts will be removed.',
                      'Clear')) {
                    await ref.read(historyProvider.notifier).clear();
                  }
                },
              ),
              _Tile(
                icon: Iconsax.global_copy,
                title: 'Clear browser history & bookmarks',
                onTap: () async {
                  if (await _confirm(context, 'Clear browser data?',
                      'Web Cast history and bookmarks will be removed.', 'Clear')) {
                    await ref.read(browserProvider.notifier).clearHistory();
                    await ref.read(browserProvider.notifier).clearBookmarks();
                  }
                },
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsetsDirectional.only(start: 4, top: AppSpace.sm),
            child: Text(
              'Clearing only removes CastFlow’s lists. Photos, videos and music on your phone are never deleted.',
              style: context.text.bodySmall,
            ),
          ),
          const SizedBox(height: AppSpace.xxl),
          // 7–12. Legal, feedback, rating, version, help
          const _GroupTitle('About & support'),
          _Group(
            children: [
              _Tile(
                icon: Iconsax.shield_tick_copy,
                title: 'Privacy Policy',
                onTap: () => openExternal(context, AppLinks.privacyPolicy),
              ),
              _Tile(
                icon: Iconsax.document_text_copy,
                title: 'Terms & Conditions',
                onTap: () => openExternal(context, AppLinks.terms),
              ),
              _Tile(
                icon: Iconsax.message_edit_copy,
                title: 'Feedback / Report a problem',
                onTap: () => _feedback(context, ref),
              ),
              _Tile(icon: Iconsax.star_1_copy, title: 'Rate app', onTap: () => _rate(context, ref)),
              _Tile(
                icon: Iconsax.info_circle_copy,
                title: 'Version',
                subtitle: 'Open the store page to check for updates',
                trailing: _Value(version == null ? '…' : '${version.version} (${version.buildNumber})'),
                onTap: () => openExternal(context, storeListingUrl),
              ),
              _Tile(icon: Iconsax.message_question_copy, title: 'Help & FAQ', onTap: () => context.push('/faq')),
            ],
          ),
          if (kDebugMode) ...[
            const SizedBox(height: AppSpace.xxl),
            const _GroupTitle('Debug (not in release builds)'),
            const _DebugTools(),
          ],
        ],
      ),
    );
  }

  Future<void> _pick<T>(
    BuildContext context, {
    required String title,
    required List<T> values,
    required T selected,
    required String Function(T) labelOf,
    required ValueChanged<T> onSelected,
  }) async {
    final picked = await showModalBottomSheet<T>(
      context: context,
      useSafeArea: true,
      builder: (context) => SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(AppSpace.xl, 0, AppSpace.xl, AppSpace.xxl),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppSpace.sm),
              child: Text(title, style: context.text.headlineMedium),
            ),
            const SizedBox(height: AppSpace.md),
            for (final v in values)
              ListTile(
                minTileHeight: kMinTap + 8,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(AppRadius.md)),
                selected: v == selected,
                selectedTileColor: context.palette.primaryTint,
                title: Text(labelOf(v), style: context.text.bodyLarge),
                trailing: v == selected ? Icon(Iconsax.tick_circle_copy, color: context.palette.primary) : null,
                onTap: () => Navigator.pop(context, v),
              ),
          ],
        ),
      ),
    );
    if (picked != null) onSelected(picked);
  }
}

class _DebugTools extends ConsumerWidget {
  const _DebugTools();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final preview = ref.watch(previewModeProvider);
    final s = ref.watch(settingsProvider);
    return SoftCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Preview data states', style: context.text.titleSmall),
          const SizedBox(height: 2),
          Text('Force the fake services to return empty results or errors.', style: context.text.bodySmall),
          const SizedBox(height: AppSpace.md),
          SegmentedPills<PreviewMode>(
            values: PreviewMode.values,
            selected: preview,
            labelOf: (m) => switch (m) {
              PreviewMode.live => 'Live',
              PreviewMode.empty => 'Empty',
              PreviewMode.error => 'Error',
            },
            onChanged: ref.read(previewModeProvider.notifier).set,
          ),
          const SizedBox(height: AppSpace.md),
          Wrap(
            spacing: AppSpace.sm,
            runSpacing: AppSpace.sm,
            children: [
              TintedButton(label: 'Ad diagnostics', compact: true, onPressed: () => context.push('/ad-diagnostics')),
              if (s.isPremium)
                TintedButton(
                  label: 'Reset Premium',
                  compact: true,
                  onPressed: () => ref.read(settingsProvider.notifier).setPremium(false),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _PremiumCard extends StatelessWidget {
  const _PremiumCard({required this.active});

  /// Reflects an active entitlement instead of upselling.
  final bool active;

  @override
  Widget build(BuildContext context) {
    return TapScale(
      onTap: active ? null : () => context.push('/premium'),
      semanticLabel: active ? 'CastFlow Pro is active' : 'Upgrade to Premium',
      child: Container(
        padding: const EdgeInsets.all(AppSpace.xl),
        decoration: BoxDecoration(
          gradient: AppColors.mainGradient,
          borderRadius: BorderRadius.circular(AppRadius.xl),
          boxShadow: AppShadows.glow(AppColors.primary),
        ),
        child: Row(
          children: [
            Container(
              width: 56,
              height: 56,
              decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.22), shape: BoxShape.circle),
              child: const Icon(Iconsax.crown_1_copy, color: Colors.white, size: 28),
            )
                .animate(onPlay: (c) => context.loopMotion(c, reverse: true))
                .rotate(begin: -0.02, end: 0.02, duration: 1400.ms),
            const SizedBox(width: AppSpace.lg),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(active ? 'CastFlow Pro is active' : 'CastFlow Premium', style: context.text.titleLarge?.copyWith(color: Colors.white)),
                  const SizedBox(height: 2),
                  Text(active ? 'Thanks for your support. Enjoy ad-free casting.' : 'No ads, 1080p mirroring & unlimited casting',
                      style: context.text.bodySmall?.copyWith(color: Colors.white.withValues(alpha: 0.9))),
                ],
              ),
            ),
            const SizedBox(width: AppSpace.sm),
            if (!active) const SoftBadge('Upgrade'),
          ],
        ),
      ),
    );
  }
}

class _GroupTitle extends StatelessWidget {
  const _GroupTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsetsDirectional.only(start: 4, bottom: AppSpace.sm),
        child: Text(text, style: context.text.labelMedium?.copyWith(color: context.palette.textSecondary)),
      );
}

class _Group extends StatelessWidget {
  const _Group({required this.children});
  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return SoftCard(
      padding: const EdgeInsets.symmetric(vertical: AppSpace.xs),
      child: Column(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            children[i],
            if (i < children.length - 1) const Divider(indent: 68, endIndent: 16),
          ],
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.title, this.subtitle, this.trailing, this.onTap});
  final IconData icon;
  final String title;
  final String? subtitle;
  final Widget? trailing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppRadius.lg),
      child: ConstrainedBox(
        constraints: const BoxConstraints(minHeight: 60),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg, vertical: AppSpace.sm),
          child: Row(
            children: [
              IconBubble(icon: icon, size: 38),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: context.text.bodyLarge),
                    if (subtitle != null) Text(subtitle!, style: context.text.bodySmall),
                  ],
                ),
              ),
              trailing ?? const ForwardChevron(),
            ],
          ),
        ),
      ),
    );
  }
}

class _Value extends StatelessWidget {
  const _Value(this.text);
  final String text;

  @override
  Widget build(BuildContext context) => Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(text, style: context.text.bodyMedium),
          const ForwardChevron(),
        ],
      );
}

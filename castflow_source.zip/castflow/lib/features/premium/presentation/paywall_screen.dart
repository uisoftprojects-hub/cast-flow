import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/config/app_links.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/launch.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/selectors.dart';
import '../../../core/widgets/soft_card.dart';
import '../../../core/widgets/state_views.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../app_flow/domain/flow_config.dart';
import '../../app_flow/presentation/app_flow_controller.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../domain/billing.dart';
import 'billing_controller.dart';

const _features = [
  (Iconsax.screenmirroring_copy, 'Full HD 1080p mirroring'),
  (Iconsax.flash_1_copy, 'Lower latency & smoother playback'),
  (Iconsax.shield_tick_copy, 'No ads, ever'),
  (Iconsax.global_copy, 'Unlimited web & app casting'),
  (Iconsax.gallery_copy, 'Unlimited slideshows'),
];

/// Paywall. With [slot] it is a startup-flow step (close advances the flow
/// and back is blocked); without it, it is a normal pushed screen.
class PaywallScreen extends ConsumerStatefulWidget {
  const PaywallScreen({super.key, this.slot});

  final String? slot;

  @override
  ConsumerState<PaywallScreen> createState() => _PaywallScreenState();
}

class _PaywallScreenState extends ConsumerState<PaywallScreen> {
  String? _selectedId;
  bool _buying = false;
  bool _restoring = false;
  bool _done = false;

  FlowStep? get _step => switch (widget.slot) {
        'a' => FlowStep.paywallFirstRunA,
        'b' => FlowStep.paywallFirstRunB,
        'returning' => FlowStep.paywallReturning,
        _ => null,
      };

  void _close() {
    final step = _step;
    if (step == null) {
      if (context.canPop()) context.pop();
      return;
    }
    final next = ref.read(appFlowProvider.notifier).advance(step);
    if (next != null) context.go(next);
  }

  void _snack(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  Future<void> _purchase(StoreProduct product) async {
    if (_buying) return;
    setState(() => _buying = true);
    final outcome = await ref.read(entitlementProvider.notifier).buy(product);
    if (!mounted) return;
    setState(() => _buying = false);
    switch (outcome) {
      case PurchaseOutcome.success:
        setState(() => _done = true);
        await Future<void>.delayed(const Duration(milliseconds: 1500));
        if (mounted) _close();
      case PurchaseOutcome.cancelled:
        _snack('Purchase cancelled.');
      case PurchaseOutcome.pending:
        _snack('Purchase pending. Pro unlocks as soon as the store confirms it.');
      case PurchaseOutcome.failed:
        _snack('Purchase failed. Please try again.');
      case PurchaseOutcome.unavailable:
        _snack('The store isn’t available right now.');
    }
  }

  Future<void> _restore() async {
    setState(() => _restoring = true);
    final found = await ref.read(entitlementProvider.notifier).restore();
    if (!mounted) return;
    setState(() => _restoring = false);
    if (found) {
      setState(() => _done = true);
      await Future<void>.delayed(const Duration(milliseconds: 1500));
      if (mounted) _close();
    } else {
      _snack('No previous purchases found for this store account.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final products = ref.watch(storeProductsProvider);
    final list = products.value ?? const <StoreProduct>[];
    final selected = list.where((x) => x.id == _selectedId).firstOrNull ??
        list.where((x) => x.id == BillingConfig.yearly).firstOrNull ??
        list.firstOrNull;

    return PopScope(
      canPop: _step == null,
      child: Scaffold(
        body: AnimatedSwitcher(
          duration: AppDurations.slow,
          child: _done
              ? const _Success()
              : ListView(
                  key: const ValueKey('paywall'),
                  padding: EdgeInsets.zero,
                  children: [
                    _Header(onClose: _close),
                    Padding(
                      padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.xxl, AppSpace.page, AppSpace.xxl),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          for (final (i, (icon, label)) in _features.indexed)
                            Padding(
                              padding: const EdgeInsets.only(bottom: AppSpace.md),
                              child: Row(
                                children: [
                                  Container(
                                    width: 28,
                                    height: 28,
                                    decoration:
                                        BoxDecoration(color: p.success.withValues(alpha: 0.2), shape: BoxShape.circle),
                                    child: const Icon(Icons.check_rounded, size: 18, color: Color(0xFF16A34A)),
                                  ),
                                  const SizedBox(width: AppSpace.md),
                                  Icon(icon, size: 18, color: p.primary),
                                  const SizedBox(width: AppSpace.sm),
                                  Expanded(child: Text(label, style: context.text.bodyLarge)),
                                ],
                              ),
                            ).animate(delay: (60 * i).ms).fadeIn().slideX(begin: 0.05, end: 0),
                          const SizedBox(height: AppSpace.lg),
                          ...products.when(
                            skipLoadingOnRefresh: false,
                            loading: () => [
                              for (var i = 0; i < 3; i++)
                                const Padding(
                                  padding: EdgeInsets.only(bottom: AppSpace.md),
                                  child: SoftShimmer(child: ShimmerBox(height: 76, radius: AppRadius.lg)),
                                ),
                            ],
                            error: (e, _) => [
                              SoftCard(
                                child: Row(
                                  children: [
                                    IconBubble(icon: Iconsax.danger_copy, color: p.error, size: 42),
                                    const SizedBox(width: AppSpace.md),
                                    Expanded(
                                      child: Text('Plans couldn’t be loaded from the store.',
                                          style: context.text.bodyMedium),
                                    ),
                                    TintedButton(
                                      label: 'Retry',
                                      compact: true,
                                      onPressed: () => ref.invalidate(storeProductsProvider),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(height: AppSpace.md),
                            ],
                            data: (items) => items.isEmpty
                                ? [
                                    Text('No plans are available right now.',
                                        textAlign: TextAlign.center, style: context.text.bodyMedium),
                                    const SizedBox(height: AppSpace.md),
                                  ]
                                : [
                                    for (final product in items)
                                      Padding(
                                        padding: const EdgeInsets.only(bottom: AppSpace.md),
                                        child: _PlanCard(
                                          product: product,
                                          selected: product.id == selected?.id,
                                          onTap: () => setState(() => _selectedId = product.id),
                                        ),
                                      ),
                                  ],
                          ),
                          const SizedBox(height: AppSpace.md),
                          GradientButton(
                            label: 'Continue',
                            expand: true,
                            loading: _buying,
                            icon: Iconsax.crown_1_copy,
                            onPressed: selected == null || _restoring ? null : () => _purchase(selected),
                          ),
                          const SizedBox(height: AppSpace.md),
                          if (selected != null)
                            Text(
                              selected.isSubscription
                                  ? 'Cancel anytime. Renews automatically until cancelled.'
                                  : 'One-time purchase. No subscription.',
                              textAlign: TextAlign.center,
                              style: context.text.bodySmall,
                            ),
                          const SizedBox(height: AppSpace.sm),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              TextButton(
                                onPressed: _restoring || _buying ? null : _restore,
                                child: Text(_restoring ? 'Restoring…' : 'Restore'),
                              ),
                              Text('·', style: context.text.bodySmall),
                              TextButton(
                                onPressed: () => openExternal(context, AppLinks.terms),
                                child: const Text('Terms'),
                              ),
                              Text('·', style: context.text.bodySmall),
                              TextButton(
                                onPressed: () => openExternal(context, AppLinks.privacyPolicy),
                                child: const Text('Privacy'),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.onClose});
  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: AppColors.mainGradient,
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(AppRadius.xl + 8)),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(AppSpace.lg, AppSpace.sm, AppSpace.lg, AppSpace.xxxl),
          child: Column(
            children: [
              Row(
                children: [
                  IconButton(
                    tooltip: 'Close',
                    onPressed: onClose,
                    icon: const Icon(Icons.close_rounded, color: Colors.white),
                    style: IconButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: 0.2)),
                  ),
                  const Spacer(),
                  ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 180),
                    child: const ConnectionChip(compact: true),
                  ),
                ],
              ),
              const SizedBox(height: AppSpace.md),
              Container(
                width: 84,
                height: 84,
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: 0.22), shape: BoxShape.circle),
                child: const Icon(Iconsax.crown_1_copy, color: Colors.white, size: 42),
              ).animate().scale(begin: const Offset(0.6, 0.6), curve: Curves.easeOutBack, duration: 600.ms),
              const SizedBox(height: AppSpace.lg),
              Text('Go Premium', style: context.text.headlineLarge?.copyWith(color: Colors.white)),
              const SizedBox(height: 4),
              Text(
                'The smoothest way to put anything on your TV.',
                textAlign: TextAlign.center,
                style: context.text.bodyMedium?.copyWith(color: Colors.white.withValues(alpha: 0.9)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PlanCard extends StatelessWidget {
  const _PlanCard({required this.product, required this.selected, required this.onTap});
  final StoreProduct product;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final period = product.period.name;
    final (title, price, note) = (period[0].toUpperCase() + period.substring(1), product.price, product.period.note);
    return Semantics(
      selected: selected,
      inMutuallyExclusiveGroup: true,
      child: TapScale(
        onTap: onTap,
        semanticLabel: '$title plan, $price, $note',
        child: AnimatedContainer(
          duration: AppDurations.medium,
          padding: const EdgeInsets.all(AppSpace.lg),
          decoration: BoxDecoration(
            color: selected ? p.primaryTint : p.surface,
            borderRadius: BorderRadius.circular(AppRadius.lg),
            border: Border.all(color: selected ? p.primary : p.divider, width: selected ? 2 : 1),
            boxShadow: selected ? AppShadows.soft(p) : null,
          ),
          child: Row(
            children: [
              AnimatedContainer(
                duration: AppDurations.medium,
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: selected ? AppColors.mainGradient : null,
                  border: selected ? null : Border.all(color: p.divider, width: 2),
                ),
                child: selected ? const Icon(Icons.check_rounded, size: 16, color: Colors.white) : null,
              ),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Wrap(
                      spacing: 8,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        Text(title, style: context.text.titleSmall),
                        if (product.period == PlanPeriod.yearly) const SoftBadge('Best value', icon: Iconsax.star_1_copy),
                      ],
                    ),
                    Text(note, style: context.text.bodySmall),
                  ],
                ),
              ),
              Text(price, style: context.text.titleLarge),
            ],
          ),
        ),
      ),
    );
  }
}

class _Success extends StatelessWidget {
  const _Success();

  @override
  Widget build(BuildContext context) {
    return Center(
      key: const ValueKey('success'),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFA4E6BF), AppColors.success]),
              shape: BoxShape.circle,
              boxShadow: AppShadows.glow(AppColors.success),
            ),
            child: const Icon(Icons.check_rounded, color: Colors.white, size: 64),
          ).animate().scale(begin: const Offset(0.3, 0.3), curve: Curves.elasticOut, duration: 900.ms),
          const SizedBox(height: AppSpace.xxl),
          Text('You’re Premium!', style: context.text.headlineLarge).animate(delay: 200.ms).fadeIn(),
          const SizedBox(height: AppSpace.sm),
          Text('Enjoy everything CastFlow has to offer.', style: context.text.bodyMedium).animate(delay: 300.ms).fadeIn(),
        ],
      ),
    );
  }
}

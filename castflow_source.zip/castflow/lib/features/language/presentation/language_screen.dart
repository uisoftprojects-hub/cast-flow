import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../app_flow/domain/flow_config.dart';
import '../../app_flow/presentation/app_flow_controller.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../monetization/domain/ad_models.dart';
import '../../monetization/presentation/native_ad_slot.dart';
import '../../settings/domain/app_settings.dart';
import '../../settings/presentation/settings_controller.dart';

/// Same screen for first-run setup and Settings → Language; the two routes
/// keep separate ad placements and only first run advances the startup flow.
class LanguageScreen extends ConsumerStatefulWidget {
  const LanguageScreen({super.key, this.fromSettings = false});

  final bool fromSettings;

  @override
  ConsumerState<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends ConsumerState<LanguageScreen> {
  late String _selected = ref.read(settingsProvider).languageCode;

  void _select(String code) {
    setState(() => _selected = code);
    // Apply immediately so the user sees layout direction change right away.
    ref.read(settingsProvider.notifier).setLanguage(code);
  }

  Future<void> _continue() async {
    await ref.read(settingsProvider.notifier).confirmLanguage(_selected);
    if (!mounted) return;
    if (widget.fromSettings) {
      context.pop();
    } else {
      final next = ref.read(appFlowProvider.notifier).advance(FlowStep.language);
      if (next != null) context.go(next);
    }
  }

  @override
  Widget build(BuildContext context) {
    final list = ListView(
      padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.sm, AppSpace.page, AppSpace.lg),
      children: [
        for (final (i, entry) in supportedLanguages.entries.indexed)
          Padding(
            padding: const EdgeInsets.only(bottom: AppSpace.sm),
            child: _LanguageRow(
              code: entry.key,
              native: entry.value.$1,
              english: entry.value.$2,
              selected: entry.key == _selected,
              onTap: () => _select(entry.key),
            ).animate(delay: (40 * i).ms).fadeIn(duration: 250.ms),
          ),
      ],
    );

    final bottom = Padding(
      padding: const EdgeInsets.fromLTRB(AppSpace.page, 0, AppSpace.page, AppSpace.lg),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          NativeAdSlot(
            placement: widget.fromSettings ? AdPlacement.languageSettings : AdPlacement.languageFirstRun,
          ),
          const SizedBox(height: AppSpace.md),
          GradientButton(
            label: widget.fromSettings ? 'Save' : 'Continue',
            icon: Iconsax.tick_circle_copy,
            expand: true,
            onPressed: _continue,
          ),
        ],
      ),
    );

    return PopScope(
      // First run can't go back to a finished step.
      canPop: widget.fromSettings,
      child: Scaffold(
        appBar: widget.fromSettings ? const CastAppBar(title: 'Language') : null,
        body: SafeArea(
          top: !widget.fromSettings,
          child: Column(
            children: [
              if (!widget.fromSettings)
                Padding(
                  padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.xl, AppSpace.page, AppSpace.md),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Choose your language', style: context.text.headlineLarge),
                      const SizedBox(height: 4),
                      Text('You can change it anytime in Settings.', style: context.text.bodyMedium),
                    ],
                  ),
                ),
              Expanded(child: list),
              bottom,
            ],
          ),
        ),
      ),
    );
  }
}

class _LanguageRow extends StatelessWidget {
  const _LanguageRow({
    required this.code,
    required this.native,
    required this.english,
    required this.selected,
    required this.onTap,
  });

  final String code;
  final String native;
  final String english;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Semantics(
      selected: selected,
      inMutuallyExclusiveGroup: true,
      child: TapScale(
        onTap: onTap,
        semanticLabel: '$english, $native',
        child: AnimatedContainer(
          duration: AppDurations.medium,
          constraints: const BoxConstraints(minHeight: 60),
          padding: const EdgeInsets.symmetric(horizontal: AppSpace.lg, vertical: AppSpace.md),
          decoration: BoxDecoration(
            color: selected ? p.primaryTint : p.surface,
            borderRadius: BorderRadius.circular(AppRadius.md),
            border: Border.all(color: selected ? p.primary : p.divider, width: selected ? 1.5 : 1),
          ),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: selected ? p.primary : p.surfaceHigh,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  code.toUpperCase(),
                  style: context.text.labelMedium?.copyWith(color: selected ? Colors.white : p.textSecondary),
                ),
              ),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(native, style: context.text.titleSmall),
                    if (native != english) Text(english, style: context.text.bodySmall),
                  ],
                ),
              ),
              AnimatedContainer(
                duration: AppDurations.medium,
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: selected ? AppColors.mainGradient : null,
                  border: selected ? null : Border.all(color: p.divider, width: 2),
                ),
                child: selected ? const Icon(Icons.check_rounded, size: 14, color: Colors.white) : null,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

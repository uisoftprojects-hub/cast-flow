import '../../../core/app_providers.dart';
import '../domain/media_models.dart';

class MockMediaRepository implements MediaRepository {
  MockMediaRepository(this._mode);

  final PreviewMode Function() _mode;

  static const _albums = [
    PhotoAlbum(id: 'all', name: 'All photos', count: 48),
    PhotoAlbum(id: 'camera', name: 'Camera', count: 24),
    PhotoAlbum(id: 'travel', name: 'Travel', count: 15),
    PhotoAlbum(id: 'family', name: 'Family', count: 12),
    PhotoAlbum(id: 'screens', name: 'Screenshots', count: 9),
  ];

  @override
  Future<List<PhotoAlbum>> albums() => simulateFetch(_mode(), () => _albums, delay: const Duration(milliseconds: 400));

  @override
  Future<List<PhotoItem>> photos(String albumId) {
    final album = _albums.firstWhere((a) => a.id == albumId, orElse: () => _albums.first);
    final now = DateTime.now();
    return simulateFetch(
      _mode(),
      () => List.generate(
        album.count,
        (i) => PhotoItem(
          id: '$albumId-$i',
          albumId: albumId,
          seed: albumId.hashCode + i * 7,
          takenAt: now.subtract(Duration(hours: i * 9)),
        ),
      ),
    );
  }

  @override
  Future<List<VideoItem>> videos() => simulateFetch(
        _mode(),
        () => const [
          VideoItem(id: 'v1', title: 'Beach sunset timelapse', duration: Duration(minutes: 2, seconds: 14), sizeBytes: 148000000, resolution: '4K', seed: 3),
          VideoItem(id: 'v2', title: 'Birthday party 🎂', duration: Duration(minutes: 12, seconds: 40), sizeBytes: 612000000, resolution: '1080p', seed: 11),
          VideoItem(id: 'v3', title: 'Mountain hike vlog', duration: Duration(minutes: 8, seconds: 5), sizeBytes: 389000000, resolution: '1080p', seed: 5),
          VideoItem(id: 'v4', title: 'Cooking pasta at home', duration: Duration(minutes: 4, seconds: 52), sizeBytes: 201000000, resolution: '720p', seed: 8),
          VideoItem(id: 'v5', title: 'Puppy’s first snow', duration: Duration(seconds: 47), sizeBytes: 38000000, resolution: '1080p', seed: 2),
          VideoItem(id: 'v6', title: 'Concert night', duration: Duration(minutes: 21, seconds: 9), sizeBytes: 1240000000, resolution: '4K', seed: 6),
          VideoItem(id: 'v7', title: 'Screen recording', duration: Duration(minutes: 1, seconds: 30), sizeBytes: 54000000, resolution: '720p', seed: 13),
        ],
      );

  @override
  Future<List<SongItem>> songs() => simulateFetch(
        _mode(),
        () => const [
          SongItem(id: 's1', title: 'Soft Morning', artist: 'Lumen', album: 'Daybreak', duration: Duration(minutes: 3, seconds: 24), seed: 1),
          SongItem(id: 's2', title: 'Ocean Drive', artist: 'Palm Haze', album: 'Coastline', duration: Duration(minutes: 4, seconds: 2), seed: 2),
          SongItem(id: 's3', title: 'Paper Planes', artist: 'Mira Vale', album: 'Origami', duration: Duration(minutes: 2, seconds: 58), seed: 3),
          SongItem(id: 's4', title: 'Midnight Tea', artist: 'Kōen', album: 'Quiet Hours', duration: Duration(minutes: 3, seconds: 41), seed: 4),
          SongItem(id: 's5', title: 'Cloud Garden', artist: 'Lumen', album: 'Daybreak', duration: Duration(minutes: 5, seconds: 10), seed: 5),
          SongItem(id: 's6', title: 'Velvet Sky', artist: 'Aria North', album: 'Aurora', duration: Duration(minutes: 3, seconds: 17), seed: 6),
          SongItem(id: 's7', title: 'Slow Rivers', artist: 'Palm Haze', album: 'Coastline', duration: Duration(minutes: 4, seconds: 45), seed: 7),
          SongItem(id: 's8', title: 'Little Lights', artist: 'Mira Vale', album: 'Origami', duration: Duration(minutes: 3, seconds: 3), seed: 8),
        ],
      );
}

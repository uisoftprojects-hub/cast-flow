import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/app_providers.dart';
import '../../../core/storage/local_store.dart';
import '../../settings/presentation/settings_controller.dart';
import '../data/fake_device_repository.dart';
import '../data/hive_saved_devices_repository.dart';
import '../domain/cast_device.dart';

final deviceRepositoryProvider = Provider<DeviceRepository>(
  (ref) => FakeDeviceRepository(() => ref.read(previewModeProvider)),
);

final savedDevicesProvider = Provider<SavedDevicesRepository>(
  (ref) => HiveSavedDevicesRepository(ref.watch(localStoreProvider).devices),
);

/// Runs discovery as a background stream so scanning never blocks the UI.
class DiscoveryController extends Notifier<DiscoveryState> {
  StreamSubscription<List<CastDevice>>? _sub;

  @override
  DiscoveryState build() {
    ref.onDispose(() => _sub?.cancel());
    return const DiscoveryState();
  }

  void scan() {
    _sub?.cancel();
    state = const DiscoveryState(scanning: true);
    _sub = ref.read(deviceRepositoryProvider).discover().listen(
      (devices) => state = state.copyWith(devices: devices),
      onError: (Object e) => state = state.copyWith(scanning: false, error: e.toString()),
      onDone: () => state = state.copyWith(scanning: false),
    );
  }

  void stop() {
    _sub?.cancel();
    state = state.copyWith(scanning: false);
  }
}

final discoveryProvider = NotifierProvider<DiscoveryController, DiscoveryState>(DiscoveryController.new);

class ConnectionController extends Notifier<CastConnection> {
  @override
  CastConnection build() => const CastConnection();

  Future<bool> connect(CastDevice device) async {
    state = CastConnection(status: ConnectionStatus.connecting, device: device);
    try {
      await ref.read(deviceRepositoryProvider).connect(device);
      state = CastConnection(status: ConnectionStatus.connected, device: device);
      ref.read(settingsProvider.notifier).rememberDevice(device.id);
      await ref.read(savedDevicesProvider).save(device.seenNow());
      return true;
    } catch (e) {
      state = CastConnection(status: ConnectionStatus.failed, device: device, error: e.toString());
      return false;
    }
  }

  Future<void> disconnect() async {
    await ref.read(deviceRepositoryProvider).disconnect();
    state = const CastConnection();
  }

  /// Reconnects to the last used device when "Auto-connect" is enabled.
  Future<void> autoConnect() async {
    final s = ref.read(settingsProvider);
    if (!s.autoConnect || s.lastDeviceId == null || state.isConnected) return;
    final device = ref.read(savedDevicesProvider).findById(s.lastDeviceId!) ??
        await ref.read(deviceRepositoryProvider).findById(s.lastDeviceId!);
    if (device != null) await connect(device);
  }
}

final connectionProvider = NotifierProvider<ConnectionController, CastConnection>(ConnectionController.new);

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/soft_card.dart';
import '../../app_flow/domain/flow_config.dart';
import '../../app_flow/presentation/app_flow_controller.dart';
import '../domain/app_permission.dart';
import 'permissions_controller.dart';

class PermissionsScreen extends ConsumerWidget {
  const PermissionsScreen({super.key});

  void _finish(BuildContext context, WidgetRef ref) {
    final next = ref.read(appFlowProvider.notifier).advance(FlowStep.permissions);
    if (next != null) context.go(next);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statuses = ref.watch(permissionsProvider);
    final allGranted = statuses.values.every((s) => s == PermissionStatus.granted);
    final anyDenied = statuses.values.any((s) => s == PermissionStatus.denied);

    return PopScope(
      canPop: false,
      child: Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.xxl, AppSpace.page, AppSpace.xxl),
          children: [
            const IconBubble(icon: Iconsax.shield_tick_copy, size: 64),
            const SizedBox(height: AppSpace.xl),
            Text('A few quick permissions', style: context.text.headlineLarge),
            const SizedBox(height: AppSpace.sm),
            Text(
              'CastFlow only uses these to find your TV and send what you choose. You can change them anytime.',
              style: context.text.bodyMedium,
            ),
            const SizedBox(height: AppSpace.xxl),
            for (final (i, perm) in AppPermission.values.indexed)
              Padding(
                padding: const EdgeInsets.only(bottom: AppSpace.md),
                child: _PermissionCard(
                  permission: perm,
                  status: statuses[perm]!,
                  onAllow: () => ref.read(permissionsProvider.notifier).request(perm),
                ).animate(delay: (80 * i).ms).fadeIn(duration: 400.ms).slideY(begin: 0.08, end: 0),
              ),
            if (anyDenied)
              Padding(
                padding: const EdgeInsets.only(bottom: AppSpace.md),
                child: Text(
                  'Some permissions were denied. You can still continue — related features will ask again when needed.',
                  style: context.text.bodySmall?.copyWith(color: context.palette.error),
                ),
              ),
            const SizedBox(height: AppSpace.lg),
            GradientButton(
              label: allGranted ? 'Continue' : 'Allow all & continue',
              expand: true,
              icon: allGranted ? Iconsax.tick_circle_copy : null,
              onPressed: () async {
                if (!allGranted) await ref.read(permissionsProvider.notifier).requestAll();
                if (context.mounted) _finish(context, ref);
              },
            ),
            const SizedBox(height: AppSpace.sm),
            Center(
              child: TextButton(
                onPressed: () => _finish(context, ref),
                style: TextButton.styleFrom(minimumSize: const Size(kMinTap, kMinTap)),
                child: Text('Maybe later', style: context.text.labelLarge?.copyWith(color: context.palette.textSecondary)),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

class _PermissionCard extends StatelessWidget {
  const _PermissionCard({required this.permission, required this.status, required this.onAllow});

  final AppPermission permission;
  final PermissionStatus status;
  final VoidCallback onAllow;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    final trailing = switch (status) {
      PermissionStatus.granted => Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Iconsax.tick_circle_copy, color: p.success, size: 20),
            const SizedBox(width: 6),
            Text('Allowed', style: context.text.labelMedium?.copyWith(color: p.success)),
          ],
        ).animate().fadeIn().scale(begin: const Offset(0.8, 0.8)),
      PermissionStatus.requesting => const SizedBox.square(
          dimension: 22,
          child: CircularProgressIndicator(strokeWidth: 2.4),
        ),
      PermissionStatus.denied => TintedButton(label: 'Retry', compact: true, color: p.error, onPressed: onAllow),
      PermissionStatus.notRequested => TintedButton(label: 'Allow', compact: true, onPressed: onAllow),
    };

    return SoftCard(
      child: Row(
        children: [
          IconBubble(icon: permission.icon, color: status == PermissionStatus.denied ? p.error : null),
          const SizedBox(width: AppSpace.lg),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(permission.title, style: context.text.titleSmall),
                const SizedBox(height: 2),
                Text(permission.description, style: context.text.bodySmall),
              ],
            ),
          ),
          const SizedBox(width: AppSpace.md),
          AnimatedSwitcher(duration: AppDurations.medium, child: KeyedSubtree(key: ValueKey(status), child: trailing)),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:iconsax_flutter/iconsax_flutter.dart';

import '../../../core/app_providers.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/theme/app_tokens.dart';
import '../../../core/utils/format.dart';
import '../../../core/widgets/buttons.dart';
import '../../../core/widgets/effects.dart';
import '../../../core/widgets/soft_card.dart';
import '../../../core/widgets/state_views.dart';
import '../../../core/widgets/tap_scale.dart';
import '../../devices/presentation/widgets/connection_chip.dart';
import '../../player/domain/cast_media.dart';
import '../../player/presentation/player_controller.dart';
import '../data/mock_media_detector.dart';
import 'browser_controller.dart';
import '../domain/web_models.dart';

final mediaDetectorProvider = Provider<MediaDetector>(
  (ref) => MockMediaDetector(() => ref.read(previewModeProvider)),
);

IconData siteIcon(String host) {
  if (host.contains('youtube')) return Iconsax.youtube_copy;
  if (host.contains('google')) return Iconsax.google_copy;
  if (host.contains('facebook')) return Iconsax.facebook_copy;
  if (host.contains('instagram')) return Iconsax.instagram_copy;
  if (host.contains('twitch')) return Iconsax.twitch_copy;
  if (host.contains('vimeo')) return Iconsax.video_circle_copy;
  if (host.contains('dailymotion')) return Iconsax.video_square_copy;
  return Iconsax.global_copy;
}

Color siteColor(String host) {
  if (host.contains('youtube')) return const Color(0xFFE62117);
  if (host.contains('google')) return const Color(0xFF4285F4);
  if (host.contains('facebook')) return const Color(0xFF1877F2);
  if (host.contains('instagram')) return const Color(0xFFE1306C);
  if (host.contains('twitch')) return const Color(0xFF9146FF);
  if (host.contains('vimeo')) return const Color(0xFF1AB7EA);
  if (host.contains('dailymotion')) return const Color(0xFF0066DC);
  return AppColors.primary;
}

/// Built-in browser with video detection. The page body is simulated until
/// webview_flutter / flutter_inappwebview is wired in.
class WebCastScreen extends ConsumerStatefulWidget {
  const WebCastScreen({super.key, this.initialUrl});

  final String? initialUrl;

  @override
  ConsumerState<WebCastScreen> createState() => _WebCastScreenState();
}

class _WebCastScreenState extends ConsumerState<WebCastScreen> {
  final _input = TextEditingController();
  final _focus = FocusNode();
  String? _url;
  AsyncValue<List<DetectedMedia>> _page = const AsyncData([]);

  @override
  void initState() {
    super.initState();
    if (widget.initialUrl != null) _open(widget.initialUrl!);
  }

  @override
  void dispose() {
    _input.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _open(String raw) async {
    final url = normalizeUrl(raw);
    if (url.isEmpty) return;
    _focus.unfocus();
    setState(() {
      _url = url;
      _input.text = url;
      _page = const AsyncLoading();
    });
    ref.read(browserProvider.notifier).visit(WebLink(title: hostOf(url), url: url, visitedAt: DateTime.now()));
    final result = await AsyncValue.guard(() => ref.read(mediaDetectorProvider).load(url));
    if (mounted && _url == url) setState(() => _page = result);
  }

  void _home() => setState(() {
        _url = null;
        _input.clear();
        _page = const AsyncData([]);
      });

  bool get _bookmarked => _url != null && ref.watch(browserProvider).bookmarks.any((b) => b.url == _url);

  void _toggleBookmark() => ref
      .read(browserProvider.notifier)
      .toggleBookmark(WebLink(title: hostOf(_url!), url: _url!, visitedAt: DateTime.now()));

  Future<void> _cast(DetectedMedia m) async {
    final media = CastMedia(
      id: m.url,
      title: m.title,
      subtitle: '${hostOf(_url ?? m.url)} · ${m.quality}',
      kind: _url != null && hostOf(_url!).contains('youtube') ? CastKind.youtube : CastKind.web,
      seed: m.seed,
      duration: m.duration,
      url: m.url,
    );
    await castAndOpenRemote(context, ref, [media]);
  }

  Future<void> _showDetected(List<DetectedMedia> items) async {
    final picked = await showModalBottomSheet<DetectedMedia>(
      context: context,
      useSafeArea: true,
      builder: (_) => _DetectedSheet(items: items),
    );
    if (picked != null && mounted) await _cast(picked);
  }

  @override
  Widget build(BuildContext context) {
    final detected = _page.value ?? const <DetectedMedia>[];
    return Scaffold(
      appBar: const CastAppBar(title: 'Web Cast'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(AppSpace.page, 0, AppSpace.page, AppSpace.sm),
            child: _UrlBar(
              controller: _input,
              focusNode: _focus,
              onSubmit: _open,
              onHome: _url == null ? null : _home,
              onReload: _url == null ? null : () => _open(_url!),
              bookmarked: _bookmarked,
              onBookmark: _url == null ? null : _toggleBookmark,
            ),
          ),
          AnimatedSwitcher(
            duration: AppDurations.fast,
            child: _page.isLoading
                ? const Padding(
                    padding: EdgeInsets.symmetric(horizontal: AppSpace.page),
                    child: ClipRRect(
                      borderRadius: BorderRadius.all(Radius.circular(4)),
                      child: LinearProgressIndicator(minHeight: 3),
                    ),
                  )
                : const SizedBox(height: 3),
          ),
          Expanded(
            child: _url == null
                ? _StartPage(
                    bookmarks: ref.watch(browserProvider).bookmarks,
                    history: ref.watch(browserProvider).history,
                    onOpen: _open,
                    onRemoveBookmark: (b) => ref.read(browserProvider.notifier).removeBookmark(b.url),
                  )
                : Stack(
                    children: [
                      _page.when(
                        skipLoadingOnRefresh: false,
                        loading: () => const _PageSkeleton(),
                        error: (e, _) => ErrorState(message: e.toString(), onRetry: () => _open(_url!)),
                        data: (_) => _SimulatedPage(url: _url!, detected: detected, onCast: _cast),
                      ),
                      if (_page.hasValue && !_page.isLoading)
                        PositionedDirectional(
                          bottom: AppSpace.xxl,
                          start: 0,
                          end: 0,
                          child: SafeArea(
                            top: false,
                            child: Center(
                              child: detected.isNotEmpty
                                  ? GradientButton(
                                      label: 'Cast this video',
                                      icon: Iconsax.screenmirroring_copy,
                                      onPressed: () =>
                                          detected.length == 1 ? _cast(detected.first) : _showDetected(detected),
                                    )
                                      .animate(onPlay: (c) => context.loopMotion(c, reverse: true))
                                      .scale(begin: const Offset(1, 1), end: const Offset(1.04, 1.04), duration: 1200.ms)
                                  : Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                                      decoration: BoxDecoration(
                                        color: context.palette.surface,
                                        borderRadius: BorderRadius.circular(AppRadius.pill),
                                        boxShadow: AppShadows.soft(context.palette),
                                      ),
                                      child: Text('No video detected on this page yet',
                                          style: context.text.labelMedium?.copyWith(color: context.palette.textSecondary)),
                                    ),
                            ).animate().fadeIn().slideY(begin: 0.5, end: 0, curve: Curves.easeOutBack),
                          ),
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

class _UrlBar extends StatelessWidget {
  const _UrlBar({
    required this.controller,
    required this.focusNode,
    required this.onSubmit,
    required this.onHome,
    required this.onReload,
    required this.bookmarked,
    required this.onBookmark,
  });

  final TextEditingController controller;
  final FocusNode focusNode;
  final ValueChanged<String> onSubmit;
  final VoidCallback? onHome;
  final VoidCallback? onReload;
  final bool bookmarked;
  final VoidCallback? onBookmark;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return Container(
      decoration: BoxDecoration(
        color: p.surface,
        borderRadius: BorderRadius.circular(AppRadius.pill),
        boxShadow: AppShadows.soft(p),
      ),
      child: Row(
        children: [
          if (onHome != null)
            IconButton(
              tooltip: 'Start page',
              onPressed: onHome,
              icon: Icon(Iconsax.home_2_copy, color: p.textSecondary, size: 20),
            )
          else
            Padding(
              padding: const EdgeInsetsDirectional.only(start: 16, end: 4),
              child: Icon(Iconsax.search_normal_1_copy, color: p.textSecondary, size: 20),
            ),
          Expanded(
            child: TextField(
              controller: controller,
              focusNode: focusNode,
              keyboardType: TextInputType.url,
              textInputAction: TextInputAction.go,
              autocorrect: false,
              onSubmitted: onSubmit,
              style: context.text.bodyLarge,
              decoration: const InputDecoration(
                hintText: 'Search or type a web address',
                filled: false,
                contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 14),
              ),
            ),
          ),
          if (onBookmark != null)
            IconButton(
              tooltip: bookmarked ? 'Remove bookmark' : 'Bookmark',
              onPressed: onBookmark,
              icon: Icon(bookmarked ? Icons.bookmark_rounded : Iconsax.bookmark_copy,
                  color: bookmarked ? p.primary : p.textSecondary, size: 20),
            ),
          if (onReload != null)
            IconButton(
              tooltip: 'Reload',
              onPressed: onReload,
              icon: Icon(Iconsax.refresh_copy, color: p.textSecondary, size: 20),
            ),
          const SizedBox(width: 4),
        ],
      ),
    );
  }
}

class _StartPage extends StatelessWidget {
  const _StartPage({required this.bookmarks, required this.history, required this.onOpen, required this.onRemoveBookmark});
  final List<WebLink> bookmarks;
  final List<WebLink> history;
  final ValueChanged<String> onOpen;
  final ValueChanged<WebLink> onRemoveBookmark;

  @override
  Widget build(BuildContext context) {
    final p = context.palette;
    return DefaultTabController(
      length: 2,
      child: NestedScrollView(
        headerSliverBuilder: (context, _) => [
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.lg, AppSpace.page, 0),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SectionHeader('Quick access'),
                  Wrap(
                    spacing: AppSpace.md,
                    runSpacing: AppSpace.lg,
                    children: [
                      for (final (i, s) in quickSites.indexed)
                        SizedBox(
                          width: 72,
                          child: TapScale(
                            onTap: () => onOpen(s.url),
                            semanticLabel: 'Open ${s.title}',
                            child: Column(
                              children: [
                                Container(
                                  width: 60,
                                  height: 60,
                                  decoration: BoxDecoration(
                                    color: p.surface,
                                    borderRadius: BorderRadius.circular(AppRadius.md),
                                    boxShadow: AppShadows.soft(p),
                                  ),
                                  child: Icon(siteIcon(hostOf(s.url)), color: siteColor(hostOf(s.url)), size: 28),
                                ),
                                const SizedBox(height: 6),
                                Text(s.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: context.text.labelSmall?.copyWith(color: p.textPrimary)),
                              ],
                            ),
                          ),
                        ).animate(delay: (40 * i).ms).fadeIn().scale(begin: const Offset(0.9, 0.9)),
                    ],
                  ),
                  const SizedBox(height: AppSpace.xxl),
                  Container(
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      color: p.surface,
                      borderRadius: BorderRadius.circular(AppRadius.pill),
                      boxShadow: AppShadows.soft(p),
                    ),
                    child: const TabBar(tabs: [Tab(text: 'Bookmarks', height: 40), Tab(text: 'History', height: 40)]),
                  ),
                ],
              ),
            ),
          ),
        ],
        body: TabBarView(
          children: [
            bookmarks.isEmpty
                ? const EmptyState(
                    icon: Iconsax.bookmark_copy,
                    title: 'No bookmarks',
                    message: 'Tap the bookmark icon in the address bar to save a page.',
                  )
                : _LinkList(
                    links: bookmarks,
                    onOpen: onOpen,
                    onRemove: onRemoveBookmark,
                  ),
            history.isEmpty
                ? const EmptyState(icon: Iconsax.clock_copy, title: 'No history', message: 'Pages you visit show up here.')
                : _LinkList(links: history, onOpen: onOpen),
          ],
        ),
      ),
    );
  }
}

class _LinkList extends StatelessWidget {
  const _LinkList({required this.links, required this.onOpen, this.onRemove});
  final List<WebLink> links;
  final ValueChanged<String> onOpen;
  final ValueChanged<WebLink>? onRemove;

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.lg, AppSpace.page, AppSpace.xxxl),
      itemCount: links.length,
      separatorBuilder: (_, _) => const SizedBox(height: AppSpace.sm),
      itemBuilder: (context, i) {
        final l = links[i];
        final host = hostOf(l.url);
        return SoftCard(
          padding: const EdgeInsets.symmetric(horizontal: AppSpace.md, vertical: AppSpace.sm),
          onTap: () => onOpen(l.url),
          semanticLabel: 'Open ${l.title}',
          child: Row(
            children: [
              IconBubble(icon: siteIcon(host), color: siteColor(host), size: 42),
              const SizedBox(width: AppSpace.md),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(l.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: context.text.titleSmall),
                    Text(
                      l.visitedAt != null ? '$host · ${formatTime(l.visitedAt!)}' : host,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: context.text.bodySmall,
                    ),
                  ],
                ),
              ),
              if (onRemove != null)
                IconButton(
                  tooltip: 'Remove',
                  onPressed: () => onRemove!(l),
                  icon: Icon(Iconsax.trash_copy, size: 18, color: context.palette.textSecondary),
                ),
            ],
          ),
        );
      },
    );
  }
}

class _PageSkeleton extends StatelessWidget {
  const _PageSkeleton();

  @override
  Widget build(BuildContext context) {
    return SoftShimmer(
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.all(AppSpace.page),
        children: const [
          ShimmerBox(height: 200, radius: AppRadius.lg),
          SizedBox(height: AppSpace.lg),
          ShimmerBox(height: 18, width: 240),
          SizedBox(height: AppSpace.sm),
          ShimmerBox(height: 14),
          SizedBox(height: AppSpace.sm),
          ShimmerBox(height: 14, width: 180),
          SizedBox(height: AppSpace.xxl),
          ShimmerBox(height: 120, radius: AppRadius.lg),
        ],
      ),
    );
  }
}

/// Stand-in page content until a real WebView is embedded.
class _SimulatedPage extends StatelessWidget {
  const _SimulatedPage({required this.url, required this.detected, required this.onCast});
  final String url;
  final List<DetectedMedia> detected;
  final ValueChanged<DetectedMedia> onCast;

  @override
  Widget build(BuildContext context) {
    final host = hostOf(url);
    return ListView(
      padding: const EdgeInsets.fromLTRB(AppSpace.page, AppSpace.md, AppSpace.page, 120),
      children: [
        Row(
          children: [
            IconBubble(icon: siteIcon(host), color: siteColor(host), size: 36),
            const SizedBox(width: AppSpace.sm),
            Expanded(child: Text(host, style: context.text.titleSmall)),
          ],
        ),
        const SizedBox(height: AppSpace.lg),
        if (detected.isNotEmpty)
          for (final m in detected) ...[
            TapScale(
              onTap: () => onCast(m),
              semanticLabel: 'Cast ${m.title}',
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: MediaArt(
                  seed: m.seed,
                  radius: AppRadius.lg,
                  icon: Iconsax.play_circle_copy,
                  iconSize: 52,
                  child: PositionedDirectional(
                    top: 10,
                    start: 10,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.3),
                        borderRadius: BorderRadius.circular(AppRadius.pill),
                      ),
                      child: Text('${m.format} · ${m.quality}',
                          style: context.text.labelSmall?.copyWith(color: Colors.white)),
                    ),
                  ),
                ),
              ),
            ),
            const SizedBox(height: AppSpace.sm),
            Text(m.title, style: context.text.titleMedium),
            Text('${formatDuration(m.duration)} · ${m.format}', style: context.text.bodySmall),
            const SizedBox(height: AppSpace.xl),
          ]
        else ...[
          for (var i = 0; i < 4; i++)
            Padding(
              padding: const EdgeInsets.only(bottom: AppSpace.md),
              child: SoftCard(
                child: Row(
                  children: [
                    SizedBox.square(dimension: 56, child: MediaArt(seed: host.hashCode + i, radius: AppRadius.sm)),
                    const SizedBox(width: AppSpace.md),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Result ${i + 1} on $host', style: context.text.titleSmall),
                          Text('A simulated page result', style: context.text.bodySmall),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
        ],
      ],
    );
  }
}

class _DetectedSheet extends StatelessWidget {
  const _DetectedSheet({required this.items});
  final List<DetectedMedia> items;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(AppSpace.xxl, 0, AppSpace.xxl, AppSpace.xxl),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Videos on this page', style: context.text.headlineMedium),
          const SizedBox(height: 4),
          Text('Pick one to send to your TV.', style: context.text.bodyMedium),
          const SizedBox(height: AppSpace.xl),
          for (final m in items)
            Padding(
              padding: const EdgeInsets.only(bottom: AppSpace.md),
              child: SoftCard(
                padding: const EdgeInsets.all(AppSpace.sm),
                child: Row(
                  children: [
                    SizedBox(
                      width: 96,
                      height: 60,
                      child: MediaArt(seed: m.seed, icon: Iconsax.play_copy, iconSize: 20, radius: AppRadius.sm),
                    ),
                    const SizedBox(width: AppSpace.md),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(m.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: context.text.titleSmall),
                          Text('${m.format} · ${m.quality} · ${formatDuration(m.duration)}', style: context.text.bodySmall),
                        ],
                      ),
                    ),
                    GradientButton(label: 'Cast', compact: true, onPressed: () => Navigator.of(context).pop(m)),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}

import 'package:castflow/features/app_flow/domain/flow_config.dart';
import 'package:castflow/features/app_flow/presentation/app_flow_controller.dart';
import 'package:castflow/features/settings/presentation/settings_controller.dart';
import 'package:flutter_test/flutter_test.dart';

import 'helpers.dart';

List<FlowStep> _flow({
  FlowConfig config = const FlowConfig(),
  bool firstLaunchCompleted = false,
  bool onboardingDone = false,
  bool languageChosen = false,
  bool isPremium = false,
}) =>
    buildFlow(
      config: config,
      firstLaunchCompleted: firstLaunchCompleted,
      onboardingDone: onboardingDone,
      languageChosen: languageChosen,
      isPremium: isPremium,
    );

void main() {
  group('buildFlow', () {
    test('first run follows the requested sequence', () {
      expect(_flow(), [
        FlowStep.entry,
        FlowStep.paywallFirstRunA,
        FlowStep.entry,
        FlowStep.language,
        FlowStep.paywallFirstRunB,
        FlowStep.onboarding,
        FlowStep.permissions,
        FlowStep.home,
      ]);
    });

    test('returning user: entry, paywall, entry, home', () {
      expect(_flow(firstLaunchCompleted: true, onboardingDone: true, languageChosen: true), [
        FlowStep.entry,
        FlowStep.paywallReturning,
        FlowStep.entry,
        FlowStep.home,
      ]);
    });

    test('a disabled paywall slot never leaves two entry gates in a row', () {
      final steps = _flow(config: const FlowConfig(paywallFirstRunA: false));
      expect(steps.take(3), [FlowStep.entry, FlowStep.language, FlowStep.paywallFirstRunB]);
    });

    test('Pro users skip every paywall', () {
      expect(_flow(isPremium: true).where((s) => s.isPaywall), isEmpty);
      expect(
        _flow(firstLaunchCompleted: true, onboardingDone: true, languageChosen: true, isPremium: true),
        [FlowStep.entry, FlowStep.home],
      );
    });

    test('an interrupted first run resumes without repeating finished steps', () {
      final steps = _flow(languageChosen: true, onboardingDone: true);
      expect(steps.contains(FlowStep.language), isFalse);
      expect(steps.contains(FlowStep.onboarding), isFalse);
      expect(steps.last, FlowStep.home);
    });
  });

  test('controller advances once per step and completes the first launch', () async {
    final c = await makeContainer();
    final flow = c.read(appFlowProvider.notifier);

    expect(flow.start(), '/entry');
    expect(flow.advance(FlowStep.entry), '/paywall?slot=a');
    // A stale/double tap on the previous step is ignored.
    expect(flow.advance(FlowStep.entry), isNull);
    expect(flow.advance(FlowStep.paywallFirstRunA), '/entry');
    expect(flow.advance(FlowStep.entry), '/language');
    expect(flow.advance(FlowStep.language), '/paywall?slot=b');
    expect(flow.advance(FlowStep.paywallFirstRunB), '/onboarding');
    expect(flow.advance(FlowStep.onboarding), '/permissions');
    expect(c.read(settingsProvider).firstLaunchCompleted, isFalse);
    expect(flow.advance(FlowStep.permissions), '/home');
    expect(c.read(settingsProvider).firstLaunchCompleted, isTrue);
    expect(c.read(appFlowProvider).finished, isTrue);
  });

  test('buying Pro mid-flow skips the remaining paywalls', () async {
    final c = await makeContainer();
    final flow = c.read(appFlowProvider.notifier)..start();
    c.read(settingsProvider.notifier).setPremium(true);
    expect(flow.advance(FlowStep.entry), '/entry');
  });
}
